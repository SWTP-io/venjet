<?php 
$title = "home";
require_once __DIR__. '/includ/head.php';


?>

<center><div class="content">
    <a href="#"><img src="/img/menu-arena.png"></a>
    <a href="#"><img src="/img/menu-mag.png"></a>
    <a href="/../apps/profile.php"><img src="/img/menu-profile.png"></a>
  
</div></center>