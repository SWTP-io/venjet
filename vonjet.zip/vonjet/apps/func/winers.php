<?php 
class LastWiners{

    public static function list(){
        for($i = 0; $i <= 5; $i++){
            echo "<div class='list'>Last 5 win team</div>";
        }
    }
    
    public static function top_list(){
        for($i = 0; $i <= 10; $i++){
            echo "<div class='top'> Top 10 users</div>";
        }
    }   
}

?>