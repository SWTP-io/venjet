<?php 
class Registration{
    private $name;
    private $password;
    
    public function __construct($name, $password){
        $this->name = $name;
        $this->password = $password;
    }
    
    public static function addUser($name, $password){
        ///Add new user on DB    
    }
}


?>