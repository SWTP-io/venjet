<?php 

class History{
    private $user;    
    public function __construct($user){
        $this->user = $user;
    }
    public static function hist(){
        //Select from DB tabe arena
    for($i = 0; $i <= 10; $i++){
        echo "<div class='user-history'>
            Your last 10 games!
        </div>";        
}
    }
}

class Profile{
    private $user;
    
    public function __construct($user){
        $this->user = $user;
    }
    
    public static function avatar($user){
        //Select from db Users avatar key
        return $img;
    }
    
    public static function hero($user){
        $list = array(mysql_query("SELECT FROM`users` WHERE`id` ='".$user."'"));
        foreach($lis as $key){
            echo $key."helo";
        }
    }
}

?>