<?php 

class Login{
    private $name;
    private $password;
    public function __construct($name, $password){
       $this->name = $name;
       $this->password = $password;
    }
    
    public function auth($name, $password){
        $_SESSION['name'] = $name;
        $_SESSION['password'] = $password;
    }
}


?>