<?php 
$title = "Profile";
require_once __DIR__. '/../includ/head.php';
require_once __DIR__. '/../apps/func/profile.php';
?>
<center>
<form method="POST" action="">
<div class="btn-group">
	<button name="profile">Profile</button>
	<button name="raiting">Raiting</button>
	<button name="history">History</button>
</div>
</form>
<?php 
if(isset($_POST['history'])){
History::hist();
}elseif(isset($_POST['raiting'])){
   echo"Your raiting is: 3"; 
}else{
echo"You see your profile";
}