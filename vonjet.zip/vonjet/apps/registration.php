<?php 
require_once __DIR__. '/../includ/system.php';
require_once __DIR__. '/../apps/func/registration.php';
$title = "Registration";
require_once __DIR__. '/../includ/head.php';

if(isset($_POST['name']) && isset($_POST['password'])){
    $_SESSION['name'] = $_POST['name'];
    $_SESSION['password'] = $_POST['password'];
    Registration::addUser($_POST['name'], $_POST['password']);
    header('location:/index.php');
    exit();
}
?>
<center><h1>Registration</h1>
<form method="POST" action="">
	<input type="text" name="name"><br />
	<input type="password" name="password"><br />
	<input type="submit" value="Submit"><a class='enter' href="/apps/login.php">Enter</a>
</form>
</center>