<?php 
require_once __DIR__. '/../apps/func/login.php';
require_once __DIR__. '/../includ/head.php';

if(isset($_POST['name']) && isset($_POST['password'])){
    Login::auth(htmlspecialchars($_POST['name']), $_POST['password']);
    header('location:/index.php');
    exit();
}
?>
<center><h1>Sig In</h1>
<form method="POST" action="">
	<input type="text" name="name"><br />
	<input type="password" name="pasword"><br />
	<input type="submit" value="Submit"><a class='enter' href="/apps/registration.php">Registration</a>
</form>
</center>