<?php 
require_once __DIR__. '/../includ/system.php';
require_once __DIR__.'/../apps/func/winers.php';
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="/../includ/style.css" type="text/css">
  <title><?=$title;?></title>
  </head>
<body>
 <header>
  <div class="wrap-logo">
  <a href="/" class="logo">Logo</a>
  </div>
  <nav>
    <a href="/">Home</a>
    <a href="/about.php">About</a>
  </nav>
</header>
<div class="top-user">
<?php LastWiners::top_list();?>
</div>
<div class="containers">
<?php LastWiners::list();?>
</div>
