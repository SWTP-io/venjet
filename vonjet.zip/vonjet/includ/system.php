<?php 
session_start();
require_once __DIR__. '/../includ/db_con.php';

$database = new Database();
$db = $database->getConnection();

?>